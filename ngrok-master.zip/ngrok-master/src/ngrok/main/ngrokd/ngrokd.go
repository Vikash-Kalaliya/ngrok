package main

import (
	"ngrok/server"
)

func main() {
	server.Main()
}
